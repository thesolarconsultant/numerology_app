"""Builds art/field.jpg — the single background field behind the whole app.

Run from the repo root: python3 tools/build-field.py

It overprints crops of the four source pieces (art/bloom-*.jpg) down a
meander. Two rules keep it seamless: each plate is faded to white inside
its own tile before it lands, so no tile edge can print as a straight
line, and consecutive plates are wider than half the sheet so the bare
paper never lines up into corridors.
"""
from PIL import Image, ImageChops, ImageDraw, ImageFilter
import os
W,H=1000,2160
PAPER=(246,240,228)
WHITE=Image.new('RGB',(W,H),(255,255,255))
SRC={k:Image.open('art/bloom-%s.jpg'%k).convert('RGB') for k in ('landing','reveal','glossary','family')}

def disc(base, key, crop, cx, cy, r, strength):
    """Fade the plate to white INSIDE its own tile. If the tile still carries ink
       at its edge, the step against the surrounding white prints as a straight
       seam — which is exactly the split that showed up before."""
    im=SRC[key]; w,h=im.size
    side=int(crop[2]*min(w,h))
    x0=max(0,min(int(crop[0]*w), w-side)); y0=max(0,min(int(crop[1]*h), h-side))
    d=2*r
    tile=im.crop((x0,y0,x0+side,y0+side)).resize((d,d),Image.LANCZOS)
    tm=Image.new('L',(d,d),0)
    ImageDraw.Draw(tm).ellipse([r-r*0.62, r-r*0.62, r+r*0.62, r+r*0.62], fill=255)
    tm=tm.filter(ImageFilter.GaussianBlur(r*0.105))
    if strength!=1.0: tm=tm.point(lambda v:int(v*strength))
    tile=Image.composite(tile, Image.new('RGB',(d,d),(255,255,255)), tm)
    canvas=WHITE.copy(); canvas.paste(tile,(cx-r,cy-r))
    return ImageChops.multiply(base, canvas)

PLATES=[
 ('landing' ,(0.00,0.30,0.90), 500, 1080,1250, .14),
 ('reveal'  ,(0.08,0.04,0.60), 500,  120, 520, .40),
 ('family'  ,(0.28,0.12,0.50), 210,  430, 480, .30),
 ('glossary',(0.05,0.10,0.62), 800,  620, 500, .26),
 ('landing' ,(0.04,0.42,0.58), 370,  860, 510, .34),
 ('reveal'  ,(0.40,0.34,0.52), 740, 1110, 480, .30),
 ('family'  ,(0.04,0.44,0.52), 280, 1330, 500, .34),
 ('glossary',(0.46,0.24,0.58), 670, 1570, 510, .26),
 ('landing' ,(0.22,0.56,0.60), 250, 1790, 480, .32),
 ('reveal'  ,(0.26,0.46,0.50), 720, 1990, 500, .34),
 ('family'  ,(0.34,0.30,0.46), 420, 2140, 460, .28),
]
base=Image.new('RGB',(W,H),PAPER)
for p in PLATES: base=disc(base,*p)
base.save('art/field.jpg',quality=82,optimize=True,progressive=True)
b=base.copy(); b.thumbnail((560,1300)); b.save('/tmp/claude-0/-home-user-numerologyapp/937d158a-bb3a-5541-ba01-9226c8d3dca1/scratchpad/field-big.jpg',quality=92)
print('field.jpg', os.path.getsize('art/field.jpg')//1024,'KB')

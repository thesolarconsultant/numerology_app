# NUMIO — deployable build

Static files, no build step. Upload the lot to the host that serves
numerology.lifestyle.

    index.html            the whole app
    manifest.webmanifest  PWA manifest
    sw.js                 service worker (cache bumped to v2 — precaches art/)
    icons/                app icons
    art/                  the background field and the animated wordmark
    tools/build-field.py  regenerates art/field.jpg from the source pieces

All four of index.html, sw.js, art/ and icons/ need to go up together: sw.js v2
precaches the art, and the app loads art/field.jpg and art/numio-mark.* by
relative path.
